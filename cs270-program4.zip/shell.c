//Garrett West
//CS 270 - Program 4: A Simple Shell
//04/15/19
//Neil Moore

#include <string.h>
#include <sys/stat.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <unistd.h>
#include <stdlib.h>
#include <stdio.h>
#include <fcntl.h>
#define buffer_size 1024
#include "shell.h"

int call_redirected(char *program, char *args[], char *outfile, char *infile){//function called for external commands
        pid_t fork_value;
        fork_value = fork();//call fork to create child process
        if (fork_value < 0){//print error if fork fails
                fprintf(stderr, "fork failed");
                return 0;
        }
        if (fork_value == 0){//child process
                int open_val = 0;
		if (outfile != NULL){//if outfile is not empty
			open_val = open(outfile, O_WRONLY|O_CREAT|O_TRUNC,0666);//open file and truncate to created
			if (open_val < 0){//if open fails output error
				fprintf(stderr, "open failed");
			}
			else{//duplicate
				int dup2_val = dup2(open_val, 1);
				if (dup2_val < 0){//print error if dup2 failed
					fprintf(stderr, "dup2 failed");
					exit(0);
				}
                	}
		}
		if (infile != NULL){//if infile is not empty
			open_val = open(infile, O_RDONLY);
			if (open_val < 0){//if open fails output error
				fprintf(stderr, "open failed");
			}
			else{//duplicate
				int dup2_val = dup2(open_val, 0);
				if (dup2_val < 0){//print error if dup2 failed
					fprintf(stderr, "dup2 failed");
					exit(0);
				}
			}
		}
                if (execvp(program, args) == -1){//print error if command execution fails
			fprintf(stderr, "Error executing thiscommanddoesnotexist. Command returned 125");
		}
        }
        if (fork_value > 1){//parent process
                int wait_val = 0;
                pid_t val_wait;
		signal(SIGINT, SIG_IGN);//blocks termination from input before wait
                val_wait = waitpid(fork_value, &wait_val, 0);//wait for child process termination
		signal(SIGINT, SIG_IGN);
                if (val_wait < 0){//output error if wait failed
                        fprintf(stderr, "wait failed");
			exit(EXIT_FAILURE);
                }
                else{//condtions for parent process success
                        if (WIFEXITED(wait_val) && WEXITSTATUS(wait_val)){
                                return 1;
                        }
                        else{
                                return 0;
                        }
                }
        }
	return 0;
}

int main(int argc, char *argv[]){//main function call
	FILE *infile;//initialize all needed pointers and variables
	char *line = NULL;
	size_t buffsize = 512;
	if (argc < 2){//condition for infile to accept user input
		infile = stdin;
	}
	else{//opens and reads file if not using input by user
		infile = fopen(argv[1], "r");
		if (infile == NULL){//output error if infile empty
			printf("failed to open\n");
			exit(1);
		}
	}
	if (infile == stdin){//output prompt if user input required
		printf("shell> ");
	}
	getline(&line, &buffsize, infile);//obtain first line from file or input
	do {//shell loop
		int pass;//dummy variable
		struct command *c = parse_command(line);//initializes command structure and parses input/file line
		if (c->args[0] == NULL){//if no command given pass through loop doing nothing
			pass = pass;
		} 
		else{//if command given
			if(!strcmp((c->args[0]),"cd")){//if commmand is 'cd'
				char *val = NULL;
				if((c->args[1])){//if given second input
					val = c->args[1];
					if (val == NULL){//if no second input given output error
						fprintf(stderr, "error");
					}
					else{//output error if directory change fails
						if((chdir(c->args[1])) == -1){
							fprintf(stderr, "Could not chdir to /does/not/exist: No such file or directory");
						}
					}
				}
				else{//if no second input given
					val = getenv("HOME");
					if (val == NULL){
						fprintf(stderr, "Error");
					}
					else{//change directory to home
						chdir(getenv("HOME"));
					}
				}
			}
			else if (!strcmp((c->args[0]),"setenv")){//if command is 'setenv'
				if ((c->args[1])){//if given second input
					if ((c->args[2])){//if given third input
						if (setenv(c->args[1], c->args[2], 1) == -1){//prints error if fails
							fprintf(stderr, "Setenv failed");
						}
					}
					else{//if given second input only 
						unsetenv(c->args[1]);
					}
				}
				else{//prints error if no subsequent inputs given
					fprintf(stderr, "Could not setenv: Invalid argument");
				}
			}	
			else if (!strcmp((c->args[0]),"exit")){//if command is 'exit'
				exit(0);
			}
			else{//if external command call required
				call_redirected(c->args[0], c->args, c->out_redir, c->in_redir);
			}
		}
		free_command(c);
		if (infile == stdin){
			printf("shell> ");
		}
	} while ((getline(&line, &buffsize, infile)) != -1);//obtain next input/file line
	exit(0);
}
